package com.example.Suman_final;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.Suman_final.model.ETodo;
import com.example.Suman_final.viewmodel.TodoViewModel;

import java.text.SimpleDateFormat;
import java.util.List;


public class ViewDataFragment extends Fragment {
    View rootview;
    TodoViewModel mTodoViewModel;
    RecyclerView todoRecyclerView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootview = inflater.inflate(R.layout.fragment_view_data, container, false);
        mTodoViewModel = ViewModelProviders.of(this).get(TodoViewModel.class);
        todoRecyclerView = rootview.findViewById(R.id.todo_recycler_view);
         todoRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));


        updateRV();
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.LEFT|ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {


                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                List<ETodo> todoList = mTodoViewModel.getmAllTodos().getValue();
                TodoAdapter adapter = new TodoAdapter(todoList);
                ETodo todo = adapter.getTodoAT(viewHolder.getAdapterPosition());
                mTodoViewModel.deleteById(todo);

            }
        }).attachToRecyclerView(todoRecyclerView);
        return rootview;

            }

    void updateRV() {
        mTodoViewModel.getmAllTodos().observe(this, new Observer<List<ETodo>>() {
            @Override
            public void onChanged(List<ETodo> todo) {

                TodoAdapter adapter = new TodoAdapter(todo);
                todoRecyclerView.setAdapter(adapter);

            }
        });
    }

    private class TodoHolder extends RecyclerView.ViewHolder {
        TextView mTitle, mDate;


        public TodoHolder(LayoutInflater inflater, ViewGroup parentViewGroup) {
            super(inflater.inflate(R.layout.list_todo_data, parentViewGroup, false));
            mTitle = itemView.findViewById(R.id.list_title);
            mDate = itemView.findViewById(R.id.list_date);

            mTitle.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    TodoAdapter todoAdapter = new TodoAdapter(mTodoViewModel.getmAllTodos().getValue());
                    int position = getAdapterPosition();
                    ETodo todo = todoAdapter.getTodo(position);
                    Intent intent = new Intent(getActivity(), EditTodoActivity.class);
                    intent.putExtra("todo_id", todo.getId());
                    startActivity(intent);
                }
            });
        }

        public void bind(ETodo todo) {
            SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
            mTitle.setText(todo.getTitle());
            mDate.setText(dateFormatter.format(todo.getTodo_date()));
        }


    }

    private class TodoAdapter extends RecyclerView.Adapter<TodoHolder> {
        List<ETodo> mTodoList;

        public TodoAdapter(List<ETodo> todoList) {
            mTodoList = todoList;
        }

        @NonNull
        @Override
        public TodoHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getContext());
            return new TodoHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(@NonNull TodoHolder holder, int position) {
            ETodo todo = mTodoList.get(position);
            LinearLayout layout=(LinearLayout)(ViewGroup)holder.mTitle.getParent();
            switch(todo.getPriority()){
                case 1:
                    layout.setBackgroundColor(getResources().getColor(R.color.High_priority));
                    break;
                case 2:
                    layout.setBackgroundColor(getResources().getColor(R.color.Medium_priority));
                    break;
                case 3:
                    layout.setBackgroundColor(getResources().getColor(R.color.low_priority));
                    break;

            }

            holder.bind(todo);
        }

        @Override
        public int getItemCount() {
            return mTodoList.size();
        }

        public ETodo getTodo(int index) {
            return mTodoList.get(index);
        }
        public ETodo getTodoAT(int index){
            return mTodoList.get(index);
        }
    }
}
